/* 2019/5/28 qshAdded */
import React, { Component } from 'react';
import { connect } from 'react-redux';
//引入ReactEcharts
import ReactEcharts from 'echarts-for-react';
//引入创建的Datepicker组件
import PropTypes, { any } from 'prop-types';

//定义从父组件接受数据的接口
interface IProps {
    dataPass: String[];
}

interface IState {
    mydata: String[];
  }

class Piechart extends Component<IProps,IState> {
           
    constructor(props:any){
        super(props);
        this.state={
              mydata: this.props.dataPass
        } 
    }

    //饼图
    getOptionPie = () => {

        //定义接收数据的props接口
        const {dataPass} =this.props;
         //console.log(this.props['barData']); //这边打印出123

        var option=({
            title:{
                text:'Case Success/Failure Count',//主标题文本，支持\n换行
                subtext: 'Analogue Data',//副文本
                // x 设置水平安放位置，默认左对齐，可选值：'center' ¦ 'left' ¦ 'right' ¦ {number}（x坐标，单位px）
                x: 'left',
                // y 设置垂直安放位置，默认全图顶端，可选值：'top' ¦ 'bottom' ¦ 'center' ¦ {number}（y坐标，单位px）
                y: 'top',

                textStyle: {
                    fontSize: 23,
                    fontWeight: 'bolder',
                  },
                // 副标题文本样式
                subtextStyle: {
                    fontSize: 16,
                    //color: '#8B2323'
                  }
      
            },
            
            // 引导线上文本样式
            textStyle: {
                fontSize: 14,
                //color: '#8B2323'
              },
            
            //图例设置  
            legend: {
                // orient 设置布局方式，默认水平布局，可选值：'horizontal'（水平） ¦ 'vertical'（垂直）
                orient: 'vertical',
                // x 设置水平安放位置，默认全图居中，可选值：'center' ¦ 'left' ¦ 'right' ¦ {number}（x坐标，单位px）
                x: 15,
                // y 设置垂直安放位置，默认全图顶端，可选值：'top' ¦ 'bottom' ¦ 'center' ¦ {number}（y坐标，单位px）
                y: 100,
                itemWidth: 24,   // 设置图例图形的宽
                itemHeight: 18,  // 设置图例图形的高
                textStyle: {
                  color: '#666'  // 图例文字颜色
                },
                // itemGap设置各个item之间的间隔，单位px，默认为10，横向布局时为水平间隔，纵向布局时为纵向间隔
                itemGap: 20,
                //backgroundColor: '#eee',  // 设置整个图例区域背景颜色
                data: ['case success','case failure']
            },  

            //值域设置
            series : [
                {
                    name: 'case success/failure',
                    type: 'pie',//每个系列，通过type决定自己的系列型号
                    radius: '55%',
                    data:[
                        {value:400, name:'case success',itemStyle: { color: '#177cb0' } },
                        {value:235, name:'case failure',itemStyle: { color: '#a1afc9' } }
                    ],
                    
                    //roseType: 'angle',  //是否展示成南丁格尔图，通过半径区分数据大小
       
                    itemStyle: {//图形样式 normal，emphasis
                        emphasis: {
                            shadowBlur: 200,
                            shadowColor: 'rgba(0, 0, 0, 0)' //第四个参数为透明度，设置为0则透明
                        }
                    },
                    label: {//饼形图上的文本标签
                        normal: {
                            textStyle: {
                                color: 'rgba(0, 0, 0, 0.3)'
                            }
                        }
                    },
                    labelLine: {//标签的视觉引导线
                        normal: {
                            lineStyle: {
                                color: 'rgba(0, 0, 0, 0.3)'
                            }
                        }
                    }
       
                }
            ],
        
            //提示框设置
            tooltip: {
                // trigger 设置触发类型，默认数据触发，可选值：'item' ¦ 'axis'
                trigger: 'item',
                showDelay: 20,   // 显示延迟，添加显示延迟可以避免频繁切换，单位ms
                hideDelay: 20,   // 隐藏延迟，单位ms
                backgroundColor: 'rgba(0,0,0,0.7)',  // 提示框背景颜色
                textStyle: {
                  fontSize: '16px',
                  color: '#FFF'  // 设置文本颜色 默认#FFF
                },
                // formatter设置提示框显示内容
                // {a}指series.name  {b}指series.data的name
                // {c}指series.data的value  {d}%指这一部分占总数的百分比
                formatter: '{a}<br/>{b}<text> num</text> : {c}({d}%)'
              }

        });
        return option;
    };

    
    
    //PROPS更新后调用
    componentWillReceiveProps(nextProps:any) {//componentWillReceiveProps方法中第一个参数代表即将传入的新的Props
        console.log("props change");
        this.setState({mydata:nextProps.dataPass});
        
    }

    
    render() {
        //测试props是否更新成功
        //console.log(this.state.mydata[1]);
        //console.log(this.props.dataPass[1]);

        return (
            <div>
                
                
                <div style={{marginTop:1}}>
                    
                    {/*case success/failure count*/}  
                    <ReactEcharts
                    option={this.getOptionPie()}
                    style={{height: '600px', width: '50%'}}
                    />
                          
                </div>

                
            </div>
        );
    }



}

//????????
(Piechart as React.ComponentClass<IProps>).propTypes = {
    dataPass: PropTypes.object.isRequired,
  } as any;

export default connect()(Piechart);