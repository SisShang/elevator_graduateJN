import React, { Component } from 'react';
import { connect } from 'react-redux';
//引入react-datepicker
import DatePicker from 'react-datepicker';
import "react-datepicker/dist/react-datepicker.css";

import Analynics from '../Analytics';
import { render } from 'react-dom';

import PropTypes, { any } from 'prop-types';

interface IState{
    text:String;
}
interface IProps{
    text:String;
}

class Child extends Component<IProps,IState> {
    constructor(props:any) {
        super(props);
        this.state = {
            text: '333'
        }
    }

    componentWillReceiveProps(nextProps:any) {
        console.log("enter");
        this.setState({
            text: nextProps.text
        });
    }

    render() {
        const {text}=this.props;
        return <p>{this.state.text}</p>
    }
}

interface IState1{
    name:String;
}
class Parent extends Component<{},IState1> {
    constructor(props:any) {
        super(props);
        this.state = {
            name: 'xxx'
        }
    }
    
    render() {
        return (
            <div>
                <Child text={this.state.name}/>
                <button onClick={() => this.setState({name: 'zzz'})}>change</button>
            </div>
        )
    }
}
(Child as React.ComponentClass<IProps>).propTypes = {
    text: PropTypes.object.isRequired,

  } as any;

export default connect()(Parent);
