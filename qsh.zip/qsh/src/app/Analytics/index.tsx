/* 2019/5/28 qshAdded */
import React, { Component } from 'react';
import { connect } from 'react-redux';
//引入ReactEcharts
import ReactEcharts from 'echarts-for-react';
//引入创建的Datepicker组件
import Datepicker from '../DatePicker';
import PropTypes, { any } from 'prop-types';

//定义从父组件接受数据的接口
interface IProps {
    dataPass: String[];
}

interface IState {
    mydata: String[];
  }

class Analytics extends Component<IProps,IState> {
           
    constructor(props:any){
        super(props);
        this.state={
              mydata: this.props.dataPass
        } 
    }
  
    //折线图
    getOptionBar = () => {
       
        var option= {
             title: {
                     text: 'Weekly Visitor Volume Enquiry',
                     subtext: 'Analogue Data'
                 },
                 tooltip: {
                     trigger: 'axis'
                 },
                 legend: {
                     data:['High']
                 },
                 toolbox: {   //辅助线开关等
                     show: true,
                     feature: {
                         dataZoom: {
                             yAxisIndex: 'none'
                         },
                         dataView: {readOnly: false},
                         magicType: {type: ['line', 'bar']},
                         restore: {},
                         saveAsImage: {}
                     }
                 },
                 xAxis:  {
                     type: 'category',
                     boundaryGap: false,  //从0刻度开始
                     data: [this.state.mydata,'25/05/2019','26/05/2019','27/05/2019','28/05/2019','29/05/2019','30/05/2019']
                     //data: this.state.data1, 

                 },
                 yAxis: {
                     type: 'value',
                     axisLabel: {
                         formatter: '{value}'
                     },
                     min:7
                 },
                 series: [
                     {
                         name:'Visitor Volume',
                         type:'line',
                         data:[11, 11, 23, 13, 12, 13, 10],
                         markPoint: {
                             data: [
                                 {type: 'max', name: 'MAX'},
                                 {type: 'min', name: 'MIN'}
                             ]
                         },
                         markLine: {
                             data: [
                                 {type: 'average', name: 'AVG'}
                             ]
                         }
                     }                  
                 ]
                };
         
         
         return option; 
    };
    
    //PROPS更新后调用
    componentWillReceiveProps(nextProps:any) {//componentWillReceiveProps方法中第一个参数代表即将传入的新的Props
        console.log("props change");
        this.setState({mydata:nextProps.dataPass});
        
    }

    
    render() {
        //测试props是否更新成功
        console.log(this.state.mydata[1]);
        console.log(this.props.dataPass[1]);

        return (
            <div>
                
                
                <div style={{marginTop:30}}>
                    
                    {/*visitor volume enquiry*/}
                    <ReactEcharts
                    option={this.getOptionBar()}
                    style={{height: '700px', width: '100%'}}
                    />
                          
                </div>

                
            </div>
        );
    }


}

//????????
(Analytics as React.ComponentClass<IProps>).propTypes = {
    dataPass: PropTypes.object.isRequired,
  } as any;

export default connect()(Analytics);