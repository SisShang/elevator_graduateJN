import React, { Component } from "react";
import { Route, Switch } from 'react-router-dom';
import Home from '../Home';
import { State } from '../../common/reducer';
import { Dispatch } from 'redux';
import { connect } from 'react-redux';
import TestCase from '../TestCase';
import PrepareCase from '../PrepareCase';
import Environment from '../Environment';
import Analytics from '../Analytics';
import Datepicker from '../DatePicker';
import Parent from '../mytest';
import PieChart from "../PieChart";


const mapStateToProps = (state: State) => {
    return {};
};

const mapDispatchToProps = (dispatch: Dispatch) => ({
});

class Content extends Component {
    render() {
        return (
            <div>
                <Switch>
                    <Route path="/" exact component={Home} />
                    <Route path="/case" component={TestCase} />
                    <Route path="/prepare" component={PrepareCase} />
                    <Route path="/environment" component={Environment} /> 
                    {/*2019/5/28 qshAdded*/}  
                    <Route path="/caseSF" component={PieChart} />      {/*path中填写url，component中访问什么组件*/}
                    <Route path="/visitorVolume" component={Datepicker} />
                    <Route path="/unknown" component={Datepicker} />  
                    <Route component={NoFound} />
                </Switch>
            </div>
        );
    }
}

class NoFound extends Component {
    render() {
        return (<div> The link "{location.pathname}" is gone away.</div>);
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Content);
