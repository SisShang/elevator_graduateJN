import React, { Component } from 'react';
import './App.css';
import AppBar from './AppBar';
import { connect } from 'react-redux';
import { push } from 'connected-react-router';
import store from '../common/store';
import { REDIRECT, MOBILE_OPEN, CLICK_LINK } from '../common/constants/actionType';
import { Dispatch } from 'redux';
import { State } from '../common/reducer';
import { MuiThemeProvider, createMuiTheme, withStyles, WithStyles, createStyles, Theme } from '@material-ui/core/styles';
import PropTypes from 'prop-types';
import CssBaseline from '@material-ui/core/CssBaseline';
import Content from './Content';
import Hidden from '@material-ui/core/Hidden';
import CTXNavigator from './CTXNavigator';

let theme = createMuiTheme({
  typography: {
    useNextVariants: true,
    h5: {
      fontWeight: 500,
      fontSize: 26,
      letterSpacing: 0.5,
    },
  },
  palette: {
    primary: {
      light: '#63ccff',
      main: '#009be5',
      dark: '#006db3',
    },
  },
  shape: {
    borderRadius: 8,
  },
});

theme = {
  ...theme,
  overrides: {
    MuiDrawer: {
      paper: {
        backgroundColor: '#18202c',
      },
    },
    MuiButton: {
      label: {
        textTransform: 'initial',
      },
      contained: {
        boxShadow: 'none',
        '&:active': {
          boxShadow: 'none',
        },
      },
    },
    MuiTabs: {
      root: {
        marginLeft: theme.spacing.unit,
      },
      indicator: {
        height: 3,
        borderTopLeftRadius: 3,
        borderTopRightRadius: 3,
        backgroundColor: theme.palette.common.white,
      },
    },
    MuiTab: {
      root: {
        textTransform: 'initial',
        margin: '0 16px',
        minWidth: 0,
        [theme.breakpoints.up('md')]: {
          minWidth: 0,
        },
      },
      labelContainer: {
        padding: 0,
        [theme.breakpoints.up('md')]: {
          padding: 0,
        },
      },
    },
    MuiIconButton: {
      root: {
        padding: theme.spacing.unit,
      },
    },
    MuiTooltip: {
      tooltip: {
        borderRadius: 4,
      },
    },
    MuiDivider: {
      root: {
        backgroundColor: '#404854',
      },
    },
    MuiListItemText: {
      primary: {
        fontWeight: theme.typography.fontWeightMedium,
      },
    },
    MuiListItemIcon: {
      root: {
        color: 'inherit',
        marginRight: 0,
        '& svg': {
          fontSize: 20,
        },
      },
    },
    MuiAvatar: {
      root: {
        width: 32,
        height: 32,
      },
    },
  },
  props: {
    MuiTab: {
      disableRipple: true,
    },
  },
  mixins: {
    ...theme.mixins,
    toolbar: {
      minHeight: 48,
    },
  },
};

const drawerWidth = 235;

const styles = (theme: Theme) =>
  createStyles({
    root: {
      display: 'flex',
      minHeight: '100vh',
    },
    drawer: {
      [theme.breakpoints.up('md')]: {
        width: drawerWidth,
        flexShrink: 0,
      },
    },
    appContent: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      width: 'calc(100% - 235px)',
    },
    mainContent: {
      flex: 1,
      padding: '48px 36px 0',
      background: '#eaeff1',
    },
  });

interface IProps extends WithStyles<typeof styles> {
  mobileOpen: boolean;
  onRedirect: () => void;
  handleDrawerToggle: () => void;
  handleLink: (id: string) => void;
}

const mapStateToProps = (state: State) => {
  return {
    redirectTo: state.common.redirectTo,
    mobileOpen: state.mobileOpen
}};

const mapDispatchToProps = (dispatch: Dispatch) => ({
  onRedirect: () =>
    dispatch({ type: REDIRECT }),
  handleDrawerToggle: () =>
    dispatch({ type: MOBILE_OPEN }),
  handleLink: (url: string) => {
    dispatch({ type: CLICK_LINK, payload: url });
  }
});

class App extends Component<IProps, {}> {
  componentWillMount() {
    this.props.handleLink(location.pathname);
  }

  componentWillReceiveProps(nextProps: any) {
    if (nextProps.redirectTo) {
      // this.context.router.replace(nextProps.redirectTo);
      store.dispatch(push(nextProps.redirectTo));
      this.props.onRedirect();
    }
  }

  render() {
    const { classes } = this.props;

    return (
      <MuiThemeProvider theme={theme}>
        <div className={classes.root}>
          <CssBaseline />
          <nav className={classes.drawer}>
            <Hidden mdUp implementation="js">    {/*hidden：导航栏CTXNavigator当页面缩放时进行隐藏*/}
              <CTXNavigator
                PaperProps={{ style: { width: drawerWidth } }}
                variant="temporary"
                open={this.props.mobileOpen}
                onClose={this.props.handleDrawerToggle}
              />
            </Hidden>
            <Hidden smDown implementation="css">
              <CTXNavigator PaperProps={{ style: { width: drawerWidth } }} />
            </Hidden>
          </nav>
          <div className={classes.appContent}>
            <AppBar />
            <main className={classes.mainContent}>
              <Content />   {/*content中为路由内容*/}
            </main>
          </div>
        </div>
      </MuiThemeProvider>
    );
  }
}

(App as React.ComponentClass<IProps>).propTypes = {
  classes: PropTypes.object.isRequired,
} as any;

export default withStyles(styles(theme))(connect(mapStateToProps, mapDispatchToProps)(App));
