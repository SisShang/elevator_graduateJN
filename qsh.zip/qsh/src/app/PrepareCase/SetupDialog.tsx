import React, {Component} from 'react';
import { connect } from 'react-redux';
import { Button, Dialog, DialogTitle, DialogContent, DialogContentText, TextField, DialogActions, FormControl } from '@material-ui/core';

const inputProps = {
    step: 10,
};

interface IProps {
    open: boolean;
    closeHandler: () => void;
}

class SetupDialog extends Component<IProps, {}> {

    render() {
        return (
            <div>
                <Dialog
                    open={this.props.open}
                    onClose={this.props.closeHandler}
                    aria-labelledby="setup-dialog-title"
                >
                    <DialogTitle id="setup-dialog-title">Set up an environment</DialogTitle>
                    <DialogContent>
                        <DialogContentText>
                            Please provide information to set up recording test environment:
                        </DialogContentText>
                        <FormControl>
                            <TextField
                                autoFocus
                                margin="dense"
                                id="asf_ip"
                                label="ASF Controller IP"
                                fullWidth
                                required
                            />
                            <TextField
                                margin="dense"
                                id="account"
                                label="Account"
                                fullWidth
                                required
                                inputProps={inputProps}
                            />
                            <TextField
                                margin="dense"
                                id="password"
                                label="Password"
                                type="password"
                                fullWidth
                                required
                            />
                        </FormControl>
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={this.props.closeHandler} color="primary">
                            OK
                        </Button>
                        <Button onClick={this.props.closeHandler}>
                            Cancel
                        </Button>
                    </DialogActions>
                </Dialog>
            </div>
        );
    }
}

export default connect()(SetupDialog);
