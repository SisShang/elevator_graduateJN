import React, {Component} from 'react';
import { connect } from 'react-redux';
import { Button, Dialog, DialogTitle, DialogContent, DialogContentText, TextField, DialogActions } from '@material-ui/core';

interface IProps {
    open: boolean;
    closeHandler: () => void;
    okHandler: () => void;
}

class StartDialog extends Component<IProps, {}> {

    render() {
        return (
            <div>
                <Dialog
                    open={this.props.open}
                    onClose={this.props.closeHandler}
                    aria-labelledby="start-dialog-title"
                >
                    <DialogTitle id="start-dialog-title">Start Record Case</DialogTitle>
                    <DialogContent>
                        <DialogContentText>
                        Please input a case name for your recording:
                        </DialogContentText>
                        <TextField
                            autoFocus
                            margin="dense"
                            id="name"
                            label="Case Name"
                            fullWidth
                        />
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={this.props.okHandler} color="primary">
                            OK
                        </Button>
                        <Button onClick={this.props.closeHandler}>
                            Cancel
                        </Button>
                    </DialogActions>
                </Dialog>
            </div>
        );
    }
}

export default connect()(StartDialog);
