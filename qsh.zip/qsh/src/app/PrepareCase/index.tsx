import { connect } from 'react-redux';
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Button, Fab } from '@material-ui/core';
import { withStyles, Theme, WithStyles } from '@material-ui/core/styles';
import AddIcon from '@material-ui/icons/Add';
import RecordSetting from '../../common/models/recordSetting.model';
import CTXColumn from '../../common/component/Table/CTXColumn';
import CTXTable from '../../common/component/Table';
import SetupDialog from './SetupDialog';
import StartDialog from './StartDialog';

enum Operation {
    Start = 0,
    Stop,
    Cancel
} 

const styles = (theme: Theme) => ({
    root: {
        width: '90%',
    },
    button: {
        margin: theme.spacing.unit,
    },
    fab: {
        margin: theme.spacing.unit,
    },
    instructions: {
        marginTop: theme.spacing.unit,
        marginBottom: theme.spacing.unit,
    },
    paper: {
        ...theme.mixins.gutters(),
        paddingTop: theme.spacing.unit * 2,
        paddingBottom: theme.spacing.unit * 2,
        marginTop: theme.spacing.unit * 2,
    }
});

interface IProps extends WithStyles<typeof styles> {

}

interface IState {
    data: RecordSetting[];
    columns: Array<CTXColumn<RecordSetting>>;
    open: boolean;
    startOpen: boolean;
    currentRecordSetting: RecordSetting; 
    selected: string[];
}

class PrepareCase extends Component<IProps, IState> {

    constructor(props: any) {
        super(props);
        let counter = 0;
        function createData(ip: string, account: string, operation: string) {
            counter += 1;
            return { id: counter.toString(), ip, account, operation };
        }

        this.state = {
            data: [
                createData('10.158.1.1', 'Administrator', 'available'),
                createData('10.158.1.2', 'Administrator', 'available'),
                createData('10.158.1.5', 'Administrator', 'running'),
                createData('10.158.10.3', 'Administrator', 'running'),
                createData('10.158.11.11', 'Administrator', 'available'),
            ],
            columns: [
                new CTXColumn<RecordSetting>('ip', false, true, 'ASF Controller IP', item => item.ip),
                new CTXColumn<RecordSetting>('account', false, true, 'Account', item => item.account),
                new CTXColumn<RecordSetting>('status', false, true, 'Status', item => item.operation),
                new CTXColumn<RecordSetting>('operation', false, true, 'Component', item => this.operationDisplay(item)),
            ],
            open: false,
            startOpen: false,
            selected: [],
            currentRecordSetting: new RecordSetting(),
        };
    }

    operationHandler = (recordItem: RecordSetting, operation: Operation) => {
        switch (operation) {
            case Operation.Start:
                this.setState({
                    startOpen: true,
                    currentRecordSetting: recordItem
                });
                break;
            case Operation.Stop:
            case Operation.Cancel:
                this.setState(state => ({
                    data: state.data.map((item: RecordSetting) => {
                        if (item.id === recordItem.id) {
                            item.operation = "available";
                        }
                        return item;
                    })
                }));
                break;
            default:
        }
    }

    operationDisplay = (recordItem: RecordSetting) => {
        switch (recordItem.operation) {
            case "available":
                return (
                    <div>
                        <Button variant="contained" color="primary" className={this.props.classes.button} onClick={ e => {this.operationHandler(recordItem, Operation.Start)}}>
                            Start
                        </Button>
                    </div>
                );
            case "running":
                return (
                    <div>
                        <Button variant="contained" color="primary" className={this.props.classes.button}  onClick={ e => {this.operationHandler(recordItem, Operation.Stop)}}>
                            Stop
                        </Button>
                        <Button variant="contained" className={this.props.classes.button}  onClick={ e => {this.operationHandler(recordItem, Operation.Cancel)}}>
                            Cancel
                        </Button>
                    </div>
                );
        }
    }

    closeHandler = () => {
        this.setState({
            open: false
        })
    }

    openHandler = () => {
        this.setState({
            open: true
        })
    }

    closeStartHandler = () => {
        this.setState({
            startOpen: false
        })
    }

    okStartHandler = () => {
        this.setState({
            startOpen: false,
            data: this.state.data.map((item: RecordSetting) => {
                if (item.id === this.state.currentRecordSetting.id) {
                    item.operation = "running";
                }
                return item;
            })
        })
    }

    handleSelectAllClick = (event: any) => {
        if (event.target.checked) {
            this.setState(state => ({ selected: state.data.map(n => n.id) }));
            return;
        }
        this.setState({ selected: [] });
    }

    handleClick = (event: any, id: string) => {
        const { selected } = this.state;
        const selectedIndex = selected.indexOf(id);
        let newSelected: string[] = [];

        if (selectedIndex === -1) {
            newSelected = newSelected.concat(selected, id);
        } else if (selectedIndex === 0) {
            newSelected = newSelected.concat(selected.slice(1));
        } else if (selectedIndex === selected.length - 1) {
            newSelected = newSelected.concat(selected.slice(0, -1));
        } else if (selectedIndex > 0) {
            newSelected = newSelected.concat(
                selected.slice(0, selectedIndex),
                selected.slice(selectedIndex + 1),
            );
        }

        this.setState({ selected: newSelected });
    }

    render() {
        const { classes } = this.props;
        const { data, columns, open, startOpen, selected } = this.state;

        return (
            <div className={classes.root}>
                <Fab size="medium" color="primary" aria-label="Add" className={classes.fab}  onClick={e => {this.openHandler()}}>
                    <AddIcon/>
                </Fab>
                <SetupDialog open={open} closeHandler={this.closeHandler} />
                <CTXTable
                    title="Recording Environment"
                    data={data}
                    columns={columns}
                    selected={selected}
                    handleSelectAllClick={this.handleSelectAllClick}
                    handleClick={this.handleClick}
                />
                <StartDialog open={startOpen} closeHandler={this.closeStartHandler} okHandler={this.okStartHandler}/>
            </div>
        );
    }
}

(PrepareCase as React.ComponentClass<IProps>).propTypes = {
    classes: PropTypes.object.isRequired,
  } as any;

export default withStyles(styles)(connect()(PrepareCase));
