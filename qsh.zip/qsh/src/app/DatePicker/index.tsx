/* 2019/5/29 qshAdded */
import React, { Component } from 'react';
import { connect } from 'react-redux';
//引入react-datepicker
import DatePicker from 'react-datepicker';
import "react-datepicker/dist/react-datepicker.css";

import Analynics from '../Analytics';
import { render } from 'react-dom';

//测试从本父组件传递到子组件Analytics的数据
let data=[{barDate:"123",author:"zhangsan"}];
// interface IState1{
//   dataPass:String;
// }
// class LoggingButton extends React.Component<{},IState1> {

//     constructor(props:any) {
//       super(props);
//       this.state = {
//         dataPass: "6666"
//       };
//     }


//     //将selectedDate与服务器交互，得到访客量数据
//     handleClick = () => {
//       console.log(selectedDate);
//       //设定一个定时器，改变data数据    
//       setTimeout(()=>{
//         this.setState({dataPass:"7777"});
//         console.log("timeout end"); 
//      },2000);
     
//     }
   
//     render() {
//       return (
//         <div>
//         <button onClick={this.handleClick}>
//         submit
//         </button>
//         </div>
//       );
//     }
//   }



//给Button传递选择的起始日期
var start=new Date();
var end=new Date();


interface IState {
  startDate: Date;
  endDate: Date;
  dataPass: String[];
}
class Datepicker extends Component<{},IState> {

    constructor(props:any) {
        super(props);
        this.state = {
          startDate: new Date(),
          endDate: new Date(),

          dataPass: ['666','777'],
        };
        this.handleChangeStart = this.handleChangeStart.bind(this);
        this.handleChangeEnd = this.handleChangeEnd.bind(this);
      }

      handleChangeStart(date:Date) {
        start=date;
        this.setState({
          startDate: date
        });
      }

      handleChangeEnd(date:Date) {
        end=date;
        this.setState({
          endDate: date
        });
      }
    
    render() {
        return (
      <div /*style={{borderStyle:'solid'}}*/>
      {/* 
        <DatePicker
        selected={this.state.startDate}
        onChange={this.handleChange}
        />
        */}

      <text>&nbsp;From:&nbsp;&nbsp;&nbsp;&nbsp;</text>
      <DatePicker
        selected={this.state.startDate}
        selectsStart
        startDate={this.state.startDate}
        endDate={this.state.endDate}
        onChange={this.handleChangeStart}
      />
      <text>&nbsp;&nbsp;&nbsp;&nbsp;To:&nbsp;&nbsp;&nbsp;&nbsp;</text>
      <DatePicker
          selected={this.state.endDate}
          selectsEnd
          startDate={this.state.startDate}
          endDate={this.state.endDate}
          onChange={this.handleChangeEnd}
          minDate={this.state.startDate}
      />





        <button onClick={() => {
          console.log("StartDate:"+start);
          console.log("endDate:"+end);
          this.setState({dataPass: ['888','999']})
        }
      }>SUBMIT</button>

        <div>
          <Analynics dataPass={this.state.dataPass}  /> 
        </div>
             
      </div>
    );
  }
}


export default connect()(Datepicker);