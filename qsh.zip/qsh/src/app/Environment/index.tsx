import React, { Component } from 'react';
import { connect } from 'react-redux';

class Environment extends Component {
    render() {
        return (
            <div>
                environment
            </div>
        );
    }
}

export default connect()(Environment);
