import React, { Component } from 'react';
import Case from '../../common/models/case.model';
import CTXTable from '../../common/component/Table';
import CTXColumn from '../../common/component/Table/CTXColumn';
import { Button, Theme, WithStyles, withStyles } from '@material-ui/core';
import RunDialog from './RunDialog';
import HttpService from '../../common/service/HttpService';
import { State } from '../../common/reducer';
import { Dispatch } from 'redux';
import { GET_CASES } from '../../common/constants/actionType';
import { connect } from 'react-redux';
import ScreenShareIcon from '@material-ui/icons/ScreenShare';

interface IState {
    columns: Array<CTXColumn<Case>>;
    selected: string[];
    open: boolean;
    envOptions: any[];
}

const styles = (theme: Theme) => ({
    button: {
        margin: theme.spacing.unit,
    },
    pBottom: {
        "margin-bottom": "4px", 
    }
});

interface IProps extends WithStyles<typeof styles> {
    data: Case[];
    loadData: () => void;
}

const mapStateToProps = (state: State) => {
    return {
      data: state.testCase.cases
  }};
  
const mapDispatchToProps = (dispatch: Dispatch) => ({
    loadData: () =>
        dispatch({ type: GET_CASES })
});

class TestCase extends Component<IProps, IState> {

    testDisplay = (status?: string, path?: string) => {
        console.log(path);
        return (
            <div>
                <p className={this.props.classes.pBottom}>{status}</p>
                { status !== 'Not_Start' && !!path &&
                    (<a href={path} target="_blank"><ScreenShareIcon/></a>)
                }
            </div>
        );
    }

    constructor(props: any) {
        super(props);

        this.state = {
            columns: [
                new CTXColumn<Case>('name', false, true, 'Name', item => item.name),
                new CTXColumn<Case>('product', false, true, 'Product', item => item.product),
                new CTXColumn<Case>('component', false, true, 'Component', item => item.component),
                new CTXColumn<Case>('en', false, true, 'EN Test Status', item => this.testDisplay(item.en_status, item.en_screenshot_path)),
                new CTXColumn<Case>('de', false, true, 'DE Test Status', item => this.testDisplay(item.de_status, item.de_screenshot_path)),
                new CTXColumn<Case>('ja', false, true, 'JA Test Status', item => this.testDisplay(item.ja_status, item.ja_screenshot_path)),
            ],
            selected: [],
            open: false,
            envOptions: [
                { value: 'envID1', label: 'environment 1'},
                { value: 'envID2', label: 'environment 2'},
                { value: 'envID3', label: 'environment 3'},
                { value: 'envID4', label: 'environment 4'},
                { value: 'envID5', label: 'environment 5'},
                { value: 'envID6', label: 'environment 6'},
            ]
        };
    }

    componentDidMount() {
        this.props.loadData();
    }

    handleSelectAllClick = (event: any) => {
        if (event.target.checked) {
            this.setState({ selected: this.props.data.map(n => n.id) });
            return;
        }
        this.setState({ selected: [] });
    }

    handleClick = (event: any, id: string) => {
        const { selected } = this.state;
        const selectedIndex = selected.indexOf(id);
        let newSelected: string[] = [];

        if (selectedIndex === -1) {
            newSelected = newSelected.concat(selected, id);
        } else if (selectedIndex === 0) {
            newSelected = newSelected.concat(selected.slice(1));
        } else if (selectedIndex === selected.length - 1) {
            newSelected = newSelected.concat(selected.slice(0, -1));
        } else if (selectedIndex > 0) {
            newSelected = newSelected.concat(
                selected.slice(0, selectedIndex),
                selected.slice(selectedIndex + 1),
            );
        }

        this.setState({ selected: newSelected });
    }

    closeHandler = () => {
        this.setState({
            open: false
        })
    }

    openHandler = () => {
        this.setState({
            open: true
        })
    }

    render() {
        const { columns, selected, open, envOptions } = this.state;
        const { data } = this.props;
        return (
            <div>
                <CTXTable
                    title="Test Case"
                    data={data}
                    columns={columns}
                    selected={selected}
                    handleSelectAllClick={this.handleSelectAllClick}
                    handleClick={this.handleClick}
                />
                <Button variant="contained" color="primary" className={this.props.classes.button} disabled={selected.length === 0} onClick={ e => {this.openHandler()}}>
                    Run
                </Button>
                <RunDialog
                    open={open}
                    closeHandler={this.closeHandler}
                    isLoading={false}
                    envOptions={envOptions}
                />
            </div>
        );
    }
}

export default withStyles(styles)(connect(mapStateToProps, mapDispatchToProps)(TestCase));
