import React, {Component} from 'react';
import { connect } from 'react-redux';
import { Button, Dialog, DialogTitle, DialogContent, DialogContentText, TextField, DialogActions, Theme, WithStyles, withStyles } from '@material-ui/core';
import Select from 'react-select';

const styles = (theme: Theme) => ({
    content: {
        height: "390px",
        width: "500px",
    },
    contentText: {
        "margin-bottom": "20px",
    }
});

interface IProps extends WithStyles<typeof styles>  {
    open: boolean;
    closeHandler: () => void;
    isLoading: boolean;
    envOptions: any[];
}

class RunDialog extends Component<IProps, {}> {

    render() {
        const { isLoading, envOptions, classes } = this.props;
        return (
            <div>
                <Dialog
                    open={this.props.open}
                    onClose={this.props.closeHandler}
                    aria-labelledby="run-case-title"
                >
                    <DialogTitle id="run-case-title">Run test case</DialogTitle>
                    <DialogContent className={classes.content}>
                        <DialogContentText className={classes.contentText}>
                            Please select an environment to run the test case:
                        </DialogContentText>
                        <Select 
                            isSearchable={true}
                            isLoading={isLoading}
                            options={envOptions}
                        />
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={this.props.closeHandler} color="primary">
                            Run
                        </Button>
                        <Button onClick={this.props.closeHandler}>
                            Cancel
                        </Button>
                    </DialogActions>
                </Dialog>
            </div>
        );
    }
}

export default withStyles(styles)(connect()(RunDialog));
