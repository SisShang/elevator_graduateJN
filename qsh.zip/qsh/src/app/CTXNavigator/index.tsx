import React, { Component } from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import { withStyles, Theme, WithStyles, createStyles } from '@material-ui/core/styles';
import Divider from '@material-ui/core/Divider';
import Drawer from '@material-ui/core/Drawer';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import HomeIcon from '@material-ui/icons/Home';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import { State } from '../../common/reducer';
import Category from '../../common/models/category.model';
import { Dispatch } from 'redux';
import { CLICK_LINK } from '../../common/constants/actionType';

const styles = (theme: Theme) => createStyles({
    categoryHeader: {
        paddingTop: 16,
        paddingBottom: 16,
    },
    categoryHeaderPrimary: {
        color: theme.palette.common.white,
    },
    item: {
        paddingTop: 4,
        paddingBottom: 4,
        color: 'rgba(255, 255, 255, 0.7)',
    },
    itemCategory: {
        backgroundColor: '#232f3e',
        boxShadow: '0 -1px 0 #404854 inset',
        paddingTop: 16,
        paddingBottom: 16,
    },
    firebase: {
        fontSize: 24,
        fontFamily: theme.typography.fontFamily,
        color: theme.palette.common.white,
    },
    itemActionable: {
        '&:hover': {
            backgroundColor: 'rgba(255, 255, 255, 0.08)',
        },
    },
    itemActiveItem: {
        color: '#4fc3f7',
    },
    itemPrimary: {
        "color": 'inherit',
        "fontSize": theme.typography.fontSize,
        '&$textDense': {
            fontSize: theme.typography.fontSize,
        },
    },
    link: {
        width: '100%',
        display: 'flex',
        '&:hover': {
            'color': 'inherit',
            'text-decoration': 'none',
        }
    },
    textDense: {},
    divider: {
        marginTop: theme.spacing.unit * 2,
    },
});

const mapStateToProps = (state: State) => {
    return {
        categories: state.categories,
    }
};

const mapDispatchToProps = (dispatch: Dispatch) => ({
        handleLink: (url: string, event: any) => {
            event.stopPropagation();
            dispatch({ type: CLICK_LINK, payload: url });
        }
    }
);

interface IProps extends WithStyles<typeof styles> {
    PaperProps: {
        style: {
            width: number;
        }
    };
    variant?: any;
    open?: boolean;
    categories: Category[];
    onClose?: () => void;
    handleLink: (url: string, event: any) => void;
}

class CTXNavigator extends Component<IProps, {}> {
    render() {
        const { classes, categories, handleLink, ...other } = this.props;

        return (
          <Drawer variant="permanent" {...other}>
            <List disablePadding>
                <ListItem className={classNames(classes.firebase, classes.item, classes.itemCategory)}>
                    Menu
                </ListItem>
                <ListItem className={classNames(classes.item, classes.itemCategory, classes.itemActionable)}>
                    <ListItemIcon>
                    <HomeIcon />
                    </ListItemIcon>
                    <ListItemText
                        classes={{
                            primary: classes.itemPrimary,
                        }}
                    >
                        <Link to="/" className={classNames(classes.itemPrimary, classes.link)} onClick={handleLink.bind(this, 'home')}>
                            Project Overview
                        </Link>
                    </ListItemText>
                </ListItem>
                {categories.map(({ id, children }) => (
                    <React.Fragment key={id}>
                        <ListItem className={classes.categoryHeader}>
                            <ListItemText
                                classes={{
                                    primary: classes.categoryHeaderPrimary,
                                }}
                            >
                                {id}
                            </ListItemText>
                        </ListItem>
                        {children.map(({ id: childId, icon, active, url }) => (
                            <ListItem
                                button
                                dense
                                key={childId}
                                className={classNames(
                                    classes.item,
                                    classes.itemActionable,
                                    active && classes.itemActiveItem,
                                )}
                            >
                                <Link to={url} className={classNames(classes.itemPrimary, classes.link)} onClick={this.props.handleLink.bind(this, url)}>
                                    <ListItemIcon>{icon}</ListItemIcon>
                                    <ListItemText
                                        classes={{
                                        primary: classes.itemPrimary,
                                        textDense: classes.textDense,
                                        }}
                                    >
                                            {childId}   
                                    </ListItemText>
                                </Link>
                            </ListItem>
                        ))}
                        <Divider className={classes.divider} />
                    </React.Fragment>
                ))}
            </List>
          </Drawer>
        );
    }
}

(CTXNavigator as React.ComponentClass<IProps>).propTypes = {
    classes: PropTypes.object.isRequired,
  } as any;

export default withStyles(styles)(connect(mapStateToProps, mapDispatchToProps)(CTXNavigator));
