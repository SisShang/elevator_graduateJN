import React, { Component } from 'react';
import HttpService from '../../common/service/HttpService';

interface State {
    test: string;
}

class Home extends Component<{}, State> {

    constructor(props: any) {
        super(props);
        let counter = 0;
        function createData(name: string, calories: number, fat: number, carbs: number, protein: number) {
            counter += 1;
            return { id: counter, name, calories, fat, carbs, protein };
        }

        this.state = {
            test: '',
        };
    }

    render() {
        const { test } = this.state;
        return (
            <div>
                This is home page.
                {test}
            </div>
        );
    }
}

export default Home;
