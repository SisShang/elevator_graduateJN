import { ofType } from "redux-observable";
import { GET_CASES, GET_CASES_SUCCESS, GET_CASES_FAILURE } from "../constants/actionType";
import { Observable, EMPTY, of } from "rxjs";
import { switchMap, map, catchError } from 'rxjs/operators';
import { AnyAction } from "redux";
import HttpService from "../service/HttpService";
import Case from "../models/case.model";

const casesEpic = (action$: Observable<AnyAction>) => action$.pipe(
    ofType(GET_CASES),
    switchMap(action => {
        return HttpService.get('/cases').pipe(
            map(res => {
                return {
                    type: GET_CASES_SUCCESS,
                    payload: res.data.map((item: any) => {
                        const temp = new Case();
                        temp.id = item.ID;
                        temp.name = item.Name;
                        temp.component = item.Component;
                        temp.product = item.Product;
                        temp.en_status = item.EN_Result;
                        temp.en_screenshot_path = item.EN_Screenshot_Location;
                        temp.de_status = item.DE_Result;
                        temp.de_screenshot_path = item.DE_Screenshot_Location;
                        temp.es_status = item.ES_Result;
                        temp.es_screenshot_path = item.ES_Screenshot_Location;
                        temp.fr_status = item.FR_Result;
                        temp.fr_screenshot_path = item.FR_Screenshot_Location;
                        temp.ja_status = item.JA_Result;
                        temp.ja_screenshot_path = item.JA_Screenshot_Location;
                        temp.ko_status = item.KO_Result;
                        temp.ko_screenshot_path = item.KO_Screenshot_Location;
                        temp.zh_status = item.ZH_Result;
                        temp.zh_screenshot_path = item.ZH_Screenshot_Location;
                        return temp;
                    })
                }
            }),
            catchError(
                error => of({
                    type: GET_CASES_FAILURE,
                    payload: error
                })
            )
        );
    })
);

export default casesEpic;
