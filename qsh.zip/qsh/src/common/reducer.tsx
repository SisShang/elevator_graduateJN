import { combineReducers } from 'redux';
import { connectRouter, RouterState } from 'connected-react-router';
import { History } from 'history';
import mobileOpen from './reducers/drawer';
import common from './reducers/common';
import categories from './reducers/categories';
import testCase from './reducers/testCase';
import Category from '../common/models/category.model';
import Case from './models/case.model';

const rootReducer = (history: History) => combineReducers({
    categories,
    common,
    mobileOpen,
    testCase,
    router: connectRouter(history)
});

export interface State {
    common: {
        redirectTo: string
    };
    mobileOpen: boolean;
    router: RouterState;
    categories: Array<Category>;
    testCase: {
        cases: Case[],
        isFetching: boolean,
        error: string
    };
}

export default rootReducer;
