export default class Category {
    id: string;
    children: {
        id: string;
        icon: JSX.Element;
        active: boolean;
        url: string;
    }[];
}
