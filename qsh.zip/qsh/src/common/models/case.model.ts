export default class Case {
    id: string;
    name: string;
    product: string;
    component: string;
    en_status?: string;
    en_screenshot_path?: string;
    en_log?: string;
    de_status?: string;
    de_screenshot_path?: string;
    de_log?: string;
    fr_status?: string;
    fr_screenshot_path?: string;
    fr_log?: string;
    es_status?: string;
    es_screenshot_path?: string;
    es_log?: string;
    zh_status?: string;
    zh_screenshot_path?: string;
    zh_log?: string;
    ja_status?: string;
    ja_screenshot_path?: string;
    ja_log?: string;
    ko_status?: string;
    ko_screenshot_path?: string;
    ko_log?: string;
}
