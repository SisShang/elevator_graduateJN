export default class RecordSetting {
    id: string;
    ip: string;
    account: string;
    operation: string;
}