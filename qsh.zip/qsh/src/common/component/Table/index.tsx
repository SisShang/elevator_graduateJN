import React from 'react';
import PropTypes from 'prop-types';
import { withStyles, WithStyles, createStyles, Theme } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import Checkbox from '@material-ui/core/Checkbox';
import CTXTableToolbar from './CTXTableToolbar';
import CTXTableHead from './CTXTableHead';

function desc(a: any, b: any, orderBy: any) {
    if (b[orderBy] < a[orderBy]) {
        return -1;
    }
    if (b[orderBy] > a[orderBy]) {
        return 1;
    }
    return 0;
}

function stableSort(array: any[], cmp: any) {
    const stabilizedThis = array.map((el, index) => [el, index]);
    stabilizedThis.sort((a, b) => {
        const order = cmp(a[0], b[0]);
        if (order !== 0) {
            return order;
        }
        return a[1] - b[1];
    });
    return stabilizedThis.map(el => el[0]);
}

function getSorting(order: string, orderBy: string) {
    return order === 'desc' ? (a: any, b: any) => desc(a, b, orderBy) : (a: any, b: any) => -desc(a, b, orderBy);
}

const styles = (theme: Theme) => createStyles({
    root: {
        width: '100%',
        marginTop: theme.spacing.unit * 3,
    },
    table: {
        minWidth: 660,
    },
    tableWrapper: {
        overflowX: 'auto',
    },
    cellPadding: {
        padding: '4px',
    },
});

interface IState {
    order: string;
    orderBy: string;
    page: number;
    rowsPerPage: number;
}

export interface IProps extends WithStyles<typeof styles> {
    data: any[];
    columns: any[];
    title: string;
    selected: string[];
    handleSelectAllClick: (event: any) => void;
    handleClick: (event: any, id: string) => void;
}

class CTXTable extends React.Component<IProps, IState> {
    state = {
        order: 'asc',
        orderBy: 'calories',
        page: 0,
        rowsPerPage: 5,
    };

    handleRequestSort = (event: any, property: string) => {
        const orderBy = property;
        let order = 'desc';

        if (this.state.orderBy === property && this.state.order === 'desc') {
            order = 'asc';
        }

        this.setState({ order, orderBy });
    }

    handleChangePage = (event: any, page: number) => {
        this.setState({ page });
    }

    handleChangeRowsPerPage = (event: any) => {
        this.setState({ rowsPerPage: event.target.value });
    }

    isSelected = (id: string) => this.props.selected.indexOf(id) !== -1;

    render() {
        const { classes, data, columns, title, selected, handleSelectAllClick, handleClick } = this.props;
        const { order, orderBy, rowsPerPage, page } = this.state;
        const emptyRows = rowsPerPage - Math.min(rowsPerPage, data.length - page * rowsPerPage);

        return (
            <Paper className={classes.root}>
                <CTXTableToolbar numSelected={selected.length} title={title} />
                <div className={classes.tableWrapper}>
                    <Table className={classes.table} aria-labelledby="tableTitle">
                        <CTXTableHead
                            numSelected={selected.length}
                            order={order}
                            orderBy={orderBy}
                            onSelectAllClick={handleSelectAllClick}
                            onRequestSort={this.handleRequestSort}
                            rowCount={data.length}
                            columns={columns}
                        />
                        <TableBody>
                        {stableSort(data, getSorting(order, orderBy))
                            .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                            .map(n => {
                            const isSelected = this.isSelected(n.id);
                            return (
                                <TableRow
                                    hover
                                    role="checkbox"
                                    aria-checked={isSelected}
                                    tabIndex={-1}
                                    key={n.id}
                                    selected={isSelected}
                                >
                                    <TableCell padding="checkbox">
                                        <Checkbox checked={isSelected} onClick={event => handleClick(event, n.id)} />
                                    </TableCell>
                                    {
                                        !!columns && columns.length > 1 &&
                                        columns.map((c, i) => {
                                            const k = n.id + i;
                                            if (i === 0) {
                                                return (<TableCell key={k} component="th" scope="row" padding="none" className={classes.cellPadding}>
                                                    {columns[0].getDisplayVaule(n)}
                                                    </TableCell>);
                                            } else {
                                                return (
                                                    <TableCell key={k} align="left" padding="none" className={classes.cellPadding}>{c.getDisplayVaule(n)}</TableCell>
                                                );
                                            }
                                        })
                                    }
                                </TableRow>
                            );
                            })}
                        {emptyRows > 0 && (
                            <TableRow style={{ height: 49 * emptyRows }}>
                                <TableCell colSpan={6} />
                            </TableRow>
                        )}
                        </TableBody>
                    </Table>
                </div>
                <TablePagination
                    rowsPerPageOptions={[5, 10, 25]}
                    component="div"
                    count={data.length}
                    rowsPerPage={rowsPerPage}
                    page={page}
                    backIconButtonProps={{
                        'aria-label': 'Previous Page',
                    }}
                    nextIconButtonProps={{
                        'aria-label': 'Next Page',
                    }}
                    onChangePage={this.handleChangePage}
                    onChangeRowsPerPage={this.handleChangeRowsPerPage}
                />
            </Paper>
        );
    }
}

export default withStyles(styles)(CTXTable);
