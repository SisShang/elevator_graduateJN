import { Checkbox, TableCell, TableHead, TableRow, TableSortLabel, Tooltip, createStyles, withStyles, WithStyles, Theme } from '@material-ui/core';
import React, { Component } from 'react';
import CTXColumn from './CTXColumn';

interface Props extends  WithStyles<typeof styles> {
    numSelected: number;
    onRequestSort: (event: any, property: any) => void;
    onSelectAllClick: (event: React.ChangeEvent) => void;
    order: any;
    orderBy: string;
    rowCount: number;
    columns: Array<CTXColumn<any>>;
}

const styles = (theme: Theme) => createStyles({
    nullStyle:{},
    cellPadding: {
        padding: '4px',
    },
});

class CTXTableHead extends Component<Props> {
    createSortHandler = (property: any) => (event: any) => {
        this.props.onRequestSort(event, property);
    }

    render() {
      const { onSelectAllClick, order, orderBy, numSelected, rowCount, columns, classes } = this.props;

      return (
        <TableHead>
            <TableRow>
                <TableCell padding="checkbox">
                    <Checkbox
                        indeterminate={numSelected > 0 && numSelected < rowCount}
                        checked={numSelected === rowCount && numSelected !== 0}
                        onChange={onSelectAllClick}
                    />
                </TableCell>
                {columns.map(
                    column => (
                        <TableCell
                            key={column.name}
                            align={column.numeric ? 'right' : 'left'}
                            padding={column.disablePadding ? 'none' : 'default'}
                            sortDirection={orderBy === column.name ? order : false}
                            className={column.disablePadding ? classes.cellPadding : classes.nullStyle}
                        >
                            <Tooltip
                                title="Sort"
                                placement={column.numeric ? 'bottom-end' : 'bottom-start'}
                                enterDelay={300}
                            >
                                <TableSortLabel
                                    active={orderBy === column.name}
                                    direction={order}
                                    onClick={this.createSortHandler(column.name)}
                                >
                                    {column.label}
                                </TableSortLabel>
                            </Tooltip>
                        </TableCell>
                    ),
                    this,
                )}
            </TableRow>
        </TableHead>
      );
    }
}

export default withStyles(styles)(CTXTableHead);
