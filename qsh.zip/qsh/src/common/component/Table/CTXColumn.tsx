export default class CTXColumn<TItem> {
    name: string;
    numeric: boolean;
    disablePadding: boolean;
    label: string;
    _getDisplayValue: (item: TItem) => any;

    constructor(name: string, numeric: boolean, disablePadding: boolean, label: string, getDisplayValue: (item: TItem) => any) {
        this.name = name;
        this.numeric = numeric;
        this.disablePadding = disablePadding;
        this.label = label;
        this._getDisplayValue = getDisplayValue;
    }

    getDisplayVaule(item: TItem): string {
        return this._getDisplayValue(item);
    }
}
