import { IconButton, Toolbar, Tooltip, Typography } from '@material-ui/core';
import DeleteIcon from '@material-ui/icons/Delete';
import FilterListIcon from '@material-ui/icons/FilterList';
import { withStyles, Theme } from '@material-ui/core/styles';
import classNames from 'classnames';
import React, { Component } from 'react';
import { lighten } from '@material-ui/core/styles/colorManipulator';

interface Props {
    classes: any;
    numSelected: number;
    title: string;
}

const toolbarStyles = (theme: Theme) => ({
    root: {
        paddingRight: theme.spacing.unit,
    },
    highlight:
        theme.palette.type === 'light'
        ? {
            color: theme.palette.secondary.main,
            backgroundColor: lighten(theme.palette.secondary.light, 0.85),
            }
        : {
            color: theme.palette.text.primary,
            backgroundColor: theme.palette.secondary.dark,
            },
    spacer: {
        flex: '1 1 100%',
    },
    actions: {
        color: theme.palette.text.secondary,
    },
    title: {
        flex: '0 0 auto',
    },
});

class CTXTableToolbar extends Component <Props> {

    render() {
        const { numSelected, classes, title } = this.props;
        return (
            <Toolbar
                className={classNames(classes.root, {
                [classes.highlight]: numSelected > 0,
                })}
            >
                <div className={classes.title}>
                {numSelected > 0 ? (
                    <Typography color="inherit" variant="subtitle1">
                    {numSelected} selected
                    </Typography>
                ) : (
                    <Typography variant="h6" id="tableTitle">
                        {title}
                    </Typography>
                )}
                </div>
                <div className={classes.spacer} />
                <div className={classes.actions}>
                {numSelected > 0 ? (
                    <Tooltip title="Delete">
                    <IconButton aria-label="Delete">
                        <DeleteIcon />
                    </IconButton>
                    </Tooltip>
                ) : (
                    <Tooltip title="Filter list">
                    <IconButton aria-label="Filter list">
                        <FilterListIcon />
                    </IconButton>
                    </Tooltip>
                )}
                </div>
            </Toolbar>
        );
    }
}

export default withStyles(toolbarStyles)(CTXTableToolbar);
