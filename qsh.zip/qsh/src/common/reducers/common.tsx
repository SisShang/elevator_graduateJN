import { Action } from "redux";
import { REDIRECT } from '../constants/actionType';

export default (state = {}, action: Action) => {
    switch (action.type) {
        case REDIRECT:
        default:
            return state;
    }
};
