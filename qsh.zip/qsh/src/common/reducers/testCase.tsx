import { AnyAction } from "redux";
import { GET_CASES_SUCCESS, GET_CASES_FAILURE, GET_CASES } from "../constants/actionType";

const defaultState = {
    cases: [],
    isFetching: false,
    error: ''
};
export default (state = defaultState, action: AnyAction) => {
    switch (action.type) {
        case GET_CASES:
            return { ...state, isFetching: true};
        case GET_CASES_SUCCESS:
            return {
                cases: action.payload,
                isFetching: false,
                error: ''
            };
        case GET_CASES_FAILURE:
            return {
                cases: state.cases,
                isFetching: false,
                error: action.payload
            };
        default:
            return state;
    }
};
