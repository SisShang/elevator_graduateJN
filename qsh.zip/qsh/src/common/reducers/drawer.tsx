import { MOBILE_OPEN } from '../constants/actionType';
import { Action } from 'redux';

export default (state = false, action: Action) => {
    switch (action.type) {
        case MOBILE_OPEN:
            return !state;
        default:
            return state;
    }
};
