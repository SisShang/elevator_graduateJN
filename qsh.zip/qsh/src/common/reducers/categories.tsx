import React from 'react';
import { AnyAction } from "redux";
import { CLICK_LINK } from '../constants/actionType';
import PeopleIcon from '@material-ui/icons/People';
import TimerIcon from '@material-ui/icons/Timer';
import SettingsIcon from '@material-ui/icons/Settings';
import ReportProblemIcon from '@material-ui/icons/ReportProblem';
import BarChartIcon from '@material-ui/icons/BarChart';
import DeveloperBoardIcon from '@material-ui/icons/DeveloperBoard';
import DescriptionIcon from '@material-ui/icons/Description';
import UpdateIcon from '@material-ui/icons/Update';

const defaultState = [
        {
            id: 'Manage',
            children: [
                { id: 'Introduction', icon: <DescriptionIcon />, active: false, url: '/introduction' },
                { id: 'Case Recording', icon: <UpdateIcon />, active: false, url: '/prepare' },
                { id: 'Case Management', icon: <DeveloperBoardIcon />, active: false, url: '/case' },
                { id: 'Environment', icon: <SettingsIcon />, active: false, url: '/environment' },
                { id: 'Authentication', icon: <PeopleIcon />, active: false, url: '/auth' },
            ],
        },
        {
            id: 'Dashboard',
            children: [
                { id: 'Analytics', icon: <BarChartIcon />, active: false, url: '/analytics' },
                { id: 'Performance', icon: <TimerIcon />, active: false, url: '/performance' },
                { id: 'Issues', icon: <ReportProblemIcon />, active: false, url: '/issues' },
            ],
        },
        //2019/6/2 qshadded
        {
            id: 'Analytics',
            children: [
                { id: 'Case Success/Failure', icon: <DescriptionIcon />, active: false, url: '/caseSF' },
                { id: 'Visitor Volume', icon: <UpdateIcon />, active: false, url: '/visitorVolume' },
                { id: 'Unknown', icon: <DeveloperBoardIcon />, active: false, url: '/unknown' },
            ],
        },

        
    ];

export default (state = defaultState, action: AnyAction) => {
    switch (action.type) {
        case CLICK_LINK:
            state.map((category) => {
                category.children.map(item => {
                    if (action.payload === item.url) {
                        item.active = true;
                    } else {
                        item.active = false;
                    }
                });
            });
            return state;
        default:
            return state;
    }
};
