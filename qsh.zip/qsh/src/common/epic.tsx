import casesEpic from './Epics/case';
import { combineEpics } from 'redux-observable';

const rootEpic = combineEpics(
    casesEpic
);

export default rootEpic;
