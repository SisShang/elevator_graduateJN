import axios, { AxiosInstance } from 'axios';
import { from } from 'rxjs';

class HttpService {
    private $http: AxiosInstance;
    constructor() {
        this.$http = axios.create({
            baseURL: process.env.REACT_APP_BASE_URL
        });
    }

    get(url: string, config = {}) {
        return from(this.$http.get(url, config));
    }

    post(url: string, data?: any, config = {}) {
        return from(this.$http.post(url, data, config));
    }

    put(url: string, data?: any, config = {}) {
        return from(this.$http.put(url, data, config));
    }

    delete(url: string, config = {}) {
        return from(this.$http.delete(url, config));
    }

    head(url: string, config = {}) {
        return from(this.$http.head(url, config));
    }

    patch(url: string, data?: any, config = {}) {
        return from(this.$http.patch(url, data, config));
    }
}

export default new HttpService();
