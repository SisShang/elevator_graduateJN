import { routerMiddleware } from 'connected-react-router';
import { applyMiddleware, createStore } from 'redux';
import { createLogger } from 'redux-logger';
import { createBrowserHistory } from 'history';
import { composeWithDevTools } from 'redux-devtools-extension/developmentOnly';
import createRootReducer from './reducer';
import { createEpicMiddleware } from 'redux-observable';
import rootEpic from './epic';

export const history = createBrowserHistory();

// Build the middleware for intercepting and dispatching navigation actions
const myRouterMiddleware = routerMiddleware(history);

const epicMiddleware = createEpicMiddleware();

const getMiddleware = () => {
    if (process.env.NODE_ENV === 'production') {
        return applyMiddleware(myRouterMiddleware, epicMiddleware);
    } else {
        // Enable additional logging in non-production environments.
        return applyMiddleware(myRouterMiddleware, epicMiddleware, createLogger());
    }
};

// set initial state in store
const preloadedState = {};

const store = createStore(
    createRootReducer(history), preloadedState, composeWithDevTools(getMiddleware()));

epicMiddleware.run(rootEpic);

export default store;
