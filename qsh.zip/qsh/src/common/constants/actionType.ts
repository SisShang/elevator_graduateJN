export const MOBILE_OPEN = Symbol('MOBILE_OPEN');
export const REDIRECT = Symbol('REDIRECT');
export const CLICK_LINK = Symbol('CLICK_LINK');
export const GET_CASES = Symbol('GET_CASES');
export const GET_CASES_SUCCESS = Symbol('GET_CASES_SUCCESS');
export const GET_CASES_FAILURE = Symbol('GET_CASES_FAILURE');
